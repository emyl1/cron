<?php
/*
 * @ PHP 7
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$bul = mysqli_query($conn, "SELECT * FROM movie_vod where download_status=1 && server_id=1");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $video_id = $listeleme["id"];
        $pid = $listeleme["movie_pid"];
        $movie_path = $listeleme["movie_path"];
        exec("sudo ps -C ffmpeg -o pid", $a);
        if (in_array($pid, $a)) {
        } else {
            if (file_exists($movie_path)) {
                $download_status = 0;
                $download_ok = 1;
                $movie_pid = 0;
            } else {
                $download_status = 0;
                $download_ok = 0;
                $movie_pid = 0;
            }
            download_control($video_id, $download_status, $download_ok, $movie_pid);
        }
    }
}

function download_control($video_id, $download_status, $download_ok, $movie_pid)
{
    // ... (download_control function implementation)
}
?>
