<?php
/*
 * @ PHP 7
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$ser = mysqli_fetch_array(mysqli_query($conn, "select * from server where id=1"));
$server_ip = $ser["server_ip"];
$server_port = $ser["server_port"];
$bul = mysqli_query($conn, "SELECT * FROM channels where stream_status=1 && transcoding=1 && server_id=1");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $pids = $listeleme["pid"];
        $stream_id = $listeleme["id"];
        $file_name = $listeleme["channel_path_1"];
        $transcode_profiles = $listeleme["transcode_profiles"];
        $outputs = $listeleme["output"];
        $channel_names = $listeleme["channel_name"];
        $control_count = $listeleme["control_count"];
        $file_names = link_control($file_name, $server_ip, $server_port);
        $transcode = mysqli_fetch_array(mysqli_query($conn, "select * from transcoding_manuel_profiles where ch_id='" . $stream_id . "'"));
        $video_codecs = $transcode["video_codec"];
        $auido_codecs = $transcode["auido_codec"];
        $presets = $transcode["preset"];
        $profiless = $transcode["profile"];
        $video_bitrates = $transcode["video_bitrate"];
        $auido_bitrates = $transcode["auido_bitrate"];
        $max_bitrates = $transcode["max_bitrate"];
        $min_bitrates = $transcode["min_bitrate"];
        $bufsizes = $transcode["bufsize"];
        $aspecs = $transcode["aspec"];
        $frame_rates = $transcode["frame_rate"];
        $screens = $transcode["screen"];
        $ars = $transcode["ar"];
        $auido_channels = $transcode["auido_channel"];
        $crfs = $transcode["crf"];
        $threads = $transcode["threads"];
        $user_agent = $transcode["user_agent"];
        if ($video_codecs == "0") {
            $video_codec = "";
        } else {
            $video_codec = "-c:v " . $video_codecs;
        }
        // ... (continue with the rest of the variable assignments)
        
        if (ps_running($pids) == NULL) {
            // ... (continue with the rest of the code)
        }
    }
}

function seflink($text)
{
    // ... (seflink function implementation)
}
?>
