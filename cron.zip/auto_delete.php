<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

include "/home/fox_codec/config.php";
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$deleteActivityQuery = "DELETE FROM activity";
$deleteActivityResult = mysqli_query($conn, $deleteActivityQuery);

if (!$deleteActivityResult) {
    echo "Error deleting activity: " . mysqli_error($conn);
}

$dir = "/home/live/";

foreach (glob($dir . "*.*") as $v) {
    if (unlink($v)) {
        echo "Deleted file: " . $v . "<br>";
    } else {
        echo "Error deleting file: " . $v . "<br>";
    }
}

mysqli_close($conn);
echo " ";
?>
