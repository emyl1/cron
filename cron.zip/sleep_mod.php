<?php
/*
 * @ PHP 7
 * @ Decoder version: 1.0.0.1
 * @ Release on: 24.03.2018
 * @ Website: http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$ayar = mysqli_fetch_array(mysqli_query($conn, "select * from server where id=1"));
$server_ip = $ayar["server_ip"];
$server_port = $ayar["server_port"];
$bul = mysqli_query($conn, "SELECT * FROM channels where stream_status=1 && sleep_mod=1 && server_id=1 && restream=0");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $stream_id = $listeleme["id"];
        $pid = $listeleme["pid"];
        $channel_path_1 = $listeleme["channel_path_1"];
        if (ps_run($pid) == NULL) {
        } else {
            $sorgu = mysqli_query($conn, "select count(id) as sayi from activity where stream_id=\"" . $stream_id . "\"");
            $gelen = mysqli_fetch_assoc($sorgu);
            if ($gelen["sayi"] > 0) {
            } else {
                sleep(1);
                $tekrar = mysqli_query($conn, "select count(id) as sayi from activity where stream_id=\"" . $stream_id . "\"");
                $tekrar_sorgu = mysqli_fetch_assoc($tekrar);
                if ($tekrar_sorgu["sayi"] > 0) {
                } else {
                    if ($pid == 0) {
                    } else {
                        $pid_no = 0;
                        $cikti = "sudo kill -9 " . $pid;
                        shell_exec($cikti);
                    }
                    mysqli_query($conn, "update channels set pid='" . $pid_no . "' where id='" . $stream_id . "'");
                }
            }
        }
    }
}
echo " ";

function ps_run($pid)
{
    if (empty($pid)) {
        return false;
    }
    return file_exists("/proc/" . $pid);
}
?>
