<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
date_default_timezone_set("Europe/London");
include "/home/fox_codec/config.php";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$bul = mysqli_query($conn, "SELECT * FROM activity");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $pid = $listeleme["pid"];
        $id = $listeleme["id"];
        exec("sudo ps -C php-fpm -o pid", $a);
        if (in_array($pid, $a)) {
            // procesul este încă în execuție
        } else {
            mysqli_query($conn, "delete from activity where id='" . $id . "'");
        }
    }
}

$suan_tarih = date("Y-m-d H:i:s");
$bulsa = mysqli_query($conn, "SELECT id,date_end,test FROM users where test=1");
if (mysqli_affected_rows($conn)) {
    while ($listele = mysqli_fetch_array($bulsa)) {
        $date_end = $listele["date_end"];
        $id = $listele["id"];
        if ($date_end < $suan_tarih) {
            mysqli_query($conn, "delete from users where id='" . $id . "'");
        }
    }
}

mysqli_close($conn);
?>
