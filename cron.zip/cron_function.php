<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function link_control($file_name, $server_ip, $server_port)
{
    if (preg_match("/https:\\/\\/(www\\.)*youtube\\.com\\/.*/", $file_name)) {
        preg_match("/[\\?\\&]v=([^\\?\\&]+)/", "" . $file_name . "", $youtube_link_1);
        $file_names = "http://" . $server_ip . ":" . $server_port . "/stream/youtube.php?watch?v=" . $youtube_link_1[1];
    } else {
        $file_names = $file_name;
    }
    return $file_names;
}

function ps_running($pid)
{
    if (empty($pid)) {
        return false;
    }
    return file_exists("/proc/" . $pid);
}

function pid_guncelle($channel_pid, $stream_id, $start_time, $conn)
{
    $query = "UPDATE channels SET pid=?, start_time=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iss", $channel_pid, $start_time, $stream_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function dosya_control($stream_id, $conn)
{
    $query = "UPDATE channels SET control_count=control_count+1 WHERE id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $stream_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function stream_stop($stream_id, $conn)
{
    $stop_time = date("Y-m-d H:i:s");
    $pid_control = 0;
    $pid_control_ok = 0;
    $control_count = 0;
    $stream_status = 0;
    $pid = 0;
    $query = "UPDATE channels SET pid=?, stream_status=?, stop_time=?, pid_control=?, pid_control_ok=?, control_count=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iiiiiis", $pid, $stream_status, $stop_time, $pid_control, $pid_control_ok, $control_count, $stream_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function download_control($video_id, $download_status, $download_ok, $movie_pid, $conn)
{
    $query = "UPDATE movie_vod SET download_status=?, download_ok=?, movie_pid=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iiii", $download_status, $download_ok, $movie_pid, $video_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

?>
