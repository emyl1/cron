<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

error_reporting(0);
include "/home/fox_codec/config.php";
$status = 1;
$transcoding_start = 1;

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$bul = mysqli_query($conn, "SELECT * FROM transcode_videos where status='" . $status . "' && transcoding_start='" . $transcoding_start . "' ORDER BY id ASC LIMIT 1");

if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $id = $listeleme["id"];
        $pid = $listeleme["pid"];
        $video_link = $listeleme["video_link"];
        exec("sudo ps -C ffmpeg -o pid", $a);
        if (in_array($pid, $a)) {
            // video is still transcoding
        } else {
            if ($pid == 0) {
                // video is not transcoding
            } else {
                $cikti = "sudo kill -9 " . $pid;
                shell_exec($cikti);
            }
            $transcoding_starts = 2;
            $statuss = 2;
            $pids = 0;
            $video_time = shell_exec("/usr/bin/timeout 15s /home/ffmpeg/ffprobe -analyzeduration 10000000 -probesize 9000000 -i \"" . $video_link . "\" -show_entries format=duration -v quiet -of csv=\"p=0\" 2>&1");
            mysqli_query($conn, "update transcode_videos set video_time='" . $video_time . "',status='" . $statuss . "',pid='" . $pids . "',transcoding_start='" . $transcoding_starts . "' where id='" . $id . "'");
        }
    }
}

$bul = mysqli_query($conn, "SELECT * FROM transcode_videos where status='" . $status . "' ORDER BY id ASC LIMIT 1");

if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        // Restul codului rămâne neschimbat
        // Denumiți funcțiile `mysql_query` cu echivalentele `mysqli_query` și asigurați-vă că utilizați conexiunea `$conn` pentru interogările MySQL

        $transcoding_starts = 1;
        $playlist_status = 0;
        $command = "/home/ffmpeg/ffmpeg -probesize 15000000 -analyzeduration 9000000 -y -threads 1 -i " . $file_path . " -i /home/fox_codec/channel_logo/" . $channel_logo . " -filter_complex \"[1:v]scale=" . $logo_width . ":" . $logo_height . " [ovrl],[0:v][ovrl] " . $logo_direction . ", " . $subtitles . " drawtext=fontfile=/home/font/Ubuntu-B.ttf: text=" . $video_text . ":fontcolor=" . $font_color . "@1.0:fontsize=" . $font_size . ":" . $text_direction . "\" -c:v libx264 -r 25 -s:v " . $video_screen . " -profile:v baseline -level 3.1 -b:v " . $video_bitrate . " -minrate " . $video_bitrate . " -maxrate " . $video_bitrate . " -bufsize " . $video_bitrate . " -aspect 16:9 -c:a aac -ar 44100 -ac 2 -strict -2 -b:a 128k -f mpegts " . $video_link . "" . " > /dev/null 2>&1 & echo \$!; ";
        $video_pid = exec($command, $output);
        mysqli_query($conn, "update transcode_videos set pid='" . $video_pid . "',transcoding_start='" . $transcoding_starts . "' where id='" . $id . "'");
        mysqli_query($conn, "update channels set playlist_status='" . $playlist_status . "' where id='" . $channel_id . "'");
    }
}

mysqli_close($conn);
?>
