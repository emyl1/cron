<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";

$start = 1;

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$plyQuery = "SELECT * FROM server WHERE start=1 ORDER BY id DESC LIMIT 1";
$plyResult = mysqli_query($conn, $plyQuery);
$ply = mysqli_fetch_array($plyResult);
$no = $ply["id"];
$server_ip = $ply["server_ip"];
$server_port = $ply["server_port"];
$finish_time = $ply["finish_time"];

$json = array();
$json["actions"] = "controls";
$data_string = json_encode($json);

$ch = curl_init("http://" . $server_ip . ":" . $server_port . "/api/data_api.php");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Content-Length: " . strlen($data_string)));
$result = curl_exec($ch);

if (empty($result)) {
    $now_time = date("Y-m-d H:i:s");
    if ($finish_time < $now_time) {
        $starts = 2;
        $updateQuery = "UPDATE server SET start=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, "ii", $starts, $no);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
} else {
    $starts = 0;
    $updateQuery = "UPDATE server SET start=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "ii", $starts, $no);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>
