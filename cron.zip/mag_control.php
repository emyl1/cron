<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
$suan_tarih = date("Y-m-d H:i:s");
include "/home/fox_codec/stalker_config.php";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$bul = mysqli_query($conn, "SELECT * FROM users");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $expire_billing_date = $listeleme["expire_billing_date"];
        $id = $listeleme["id"];
        if ($suan_tarih <= $expire_billing_date) {
            echo "geçmemiş";
        } else {
            $status = 1;
            $query = "UPDATE users SET status=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "ii", $status, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }
}

mysqli_close($conn);
?>
