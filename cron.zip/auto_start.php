<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$ser = mysqli_fetch_array(mysqli_query($conn, "select * from server where id=1"));
$server_ip = $ser["server_ip"];
$server_port = $ser["server_port"];

$bul = mysqli_query($conn, "SELECT * FROM channels where stream_status=1 && transcoding=0 && sleep_mod=0 && server_id=1 && restream=0");

if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $pid = $listeleme["pid"];
        $stream_id = $listeleme["id"];
        $channels_path_1 = $listeleme["channel_path_1"];
        $channel_path_2 = $listeleme["channel_path_2"];
        $channel_path_3 = $listeleme["channel_path_3"];
        $working_channel = $listeleme["working_channel"];
        $channel_type = $listeleme["channel_type"];
        $playlist_status = $listeleme["playlist_status"];

        // Restul codului rămâne neschimbat
        // Denumiți funcțiile `mysql_query` cu echivalentele `mysqli_query` și asigurați-vă că utilizați conexiunea `$conn` pentru interogările MySQL

        $start_time = date("Y-m-d H:i:s");
        pid_guncelle($channel_pid, $stream_id, $start_time);
    }
}

$kanal_calis = mysqli_query($conn, "SELECT  COUNT(id) as sayi FROM channels WHERE stream_status=1 && server_id=1");
$gelen = mysqli_fetch_assoc($kanal_calis);

if ($gelen["sayi"] == 0) {
    $trans_calis = mysqli_query($conn, "SELECT  COUNT(id) as sayi FROM transcode_videos WHERE status=1");
    $gelenler = mysqli_fetch_assoc($trans_calis);

    if ($gelenler["sayi"] == 0) {
        $download = mysqli_query($conn, "SELECT  COUNT(id) as sayi FROM movie_vod WHERE download_status=1");
        $gelens = mysqli_fetch_assoc($download);

        if ($gelens["sayi"] == 0) {
            shell_exec("sudo killall ffmpeg 2>&1 1> /dev/null");
            mysqli_query($conn, "delete from activity");
            shell_exec("/bin/rm -r /home/live/*");
        }
    }
}

mysqli_close($conn);

echo " ";

function AddPlayTimesss($times)
{
    // Funcția AddPlayTimesss() nu a fost modificată, așa că rămâne neschimbată
    // Asigurați-vă că funcțiile utilizate în această funcție sunt compatibile cu MySQLi
}
?>
