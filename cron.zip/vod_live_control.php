<?php
/*
 * @ PHP 7
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$bul = mysqli_query($conn, "SELECT * FROM channels where stream_status=1 && server_id=1 && channel_type=3");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $stream_id = $listeleme["id"];
        $video_name = "/home/live/" . $stream_id . "_.m3u8";
        $video_time = shell_exec("/usr/bin/timeout 15s /home/ffmpeg/ffprobe -analyzeduration 10000000 -probesize 9000000 -i \"" . $video_name . "\" -show_entries format=start_time -v quiet -of csv=\"p=0\" 2>&1");
        if (empty($video_time)) {
        } else {
            mysqli_query($conn, "update vod_channel_time set stream_close_time='" . $video_time . "' where ch_id='" . $stream_id . "'");
        }
    }
}
echo " ";
?>
