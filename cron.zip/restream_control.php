<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$bul = mysqli_query($conn, "SELECT * FROM channels where transcoding=0 && server_id=1 && restream=1 && stream_status=1");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $id = $listeleme["id"];
        $working_channel = $listeleme["working_channel"];
        $channel_path_1 = $listeleme["channel_path_1"];
        $channel_path_2 = $listeleme["channel_path_2"];
        $channel_path_3 = $listeleme["channel_path_3"];
        
        if ($working_channel == 1) {
            $file_names = $channel_path_1;
        } else if ($working_channel == 2) {
            $file_names = $channel_path_2;
        } else if ($working_channel == 3) {
            $file_names = $channel_path_3;
        }
        
        $checkstreamurl = shell_exec("/usr/bin/timeout 10s /home/ffmpeg/ffprobe -analyzeduration 10000000 -probesize 9000000 -i \"" . $file_names . "\" -v  quiet -print_format json -show_streams 2>&1");
        $streaminfo = (array) json_decode($checkstreamurl);
        
        if (count($streaminfo) > 0) {
            $restream_status = 1;
        } else {
            $restream_status = 0;
        }
        
        $updateQuery = "UPDATE channels SET restream_status=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, "ii", $restream_status, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

mysqli_close($conn);
?>
