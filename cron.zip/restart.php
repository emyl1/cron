<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

include "/home/fox_codec/config.php";
include "/home/fox_codec/function/function.php";
restart();

function restart()
{
    $output = shell_exec("sudo killall ffmpeg 2>&1 1> /dev/null");
    $status = 1;
    $transcoding_start = 0;
    
    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $updateQuery = "UPDATE transcode_videos SET transcoding_start=?, status=? WHERE status=?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "iii", $transcoding_start, $status, $status);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    sleep(1);

    $deleteQuery = "DELETE FROM activity";
    mysqli_query($conn, $deleteQuery);

    shell_exec("/bin/rm -r /home/live/*");

    sleep(1);

    shell_exec("sudo /sbin/shutdown -r now");

    mysqli_close($conn);
}
?>
