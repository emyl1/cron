<?php
/*
 * @ PHP 7.4
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$ser = mysqli_fetch_array(mysqli_query($conn, "select * from server where id=1"));
$server_ip = $ser["server_ip"];
$server_port = $ser["server_port"];
$status = 1;
$download_start = 1;
$bul = mysqli_query($conn, "SELECT * FROM videos_downloader where status='" . $status . "' && download_start='" . $download_start . "'");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $id = $listeleme["id"];
        $pid = $listeleme["pid"];
        $category_id = $listeleme["category_id"];
        $download_type = $listeleme["download_type"];
        $video_name = $listeleme["video_name"];
        $server_id = $listeleme["server_id"];
        $file_path = $listeleme["file_path"];
        $movie_format = $listeleme["movie_format"];
        $logo = $listeleme["logo"];
        $movie_size = $listeleme["movie_size"];
        $movie_types = '1';
        if ($download_type == 1 || $download_type == 2) {
            $program = "wget";
        }
        $a = [];
        exec("sudo ps -C " . $program . " -o pid", $a);
        if (in_array($pid, $a)) {
        } else {
            $download_starts = 2;
            $statuss = 2;
            $pids = 0;
            mysqli_query($conn, "delete from videos_downloader where id='" . $id . "'");
            
            mysqli_query($conn, "INSERT INTO movie_vod (movie_image, category_id, server_id, movie_name, movie_path, movie_format, movie_size, movie_type) VALUES ('".$logo."', '".$category_id."', '".$server_id."', '".$video_name."', '".$file_path."', '".$movie_format."', '".$movie_size."', '".$movie_types."')");
        }
    }
}
$bul = mysqli_query($conn, "SELECT * FROM videos_downloader where status=1 LIMIT 5");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $pid = $listeleme["pid"];
        $stream_id = $listeleme["id"];
        $download_type = $listeleme["download_type"];
        $file_path = $listeleme["file_path"];
        $video_url = $listeleme["video_url"];
        $logo = $listeleme["logo"];
        if ($download_type == 1 || $download_type == 2) {
            $program = "wget";
        }
        $a = [];
        exec("sudo ps -C " . $program . " -o pid", $a);
        if (in_array($pid, $a)) {
        } else {
            if ($download_type == 1 || $download_type == 2) {
                $command = "wget " . $video_url . " -O " . $file_path . " > /dev/null 2>&1 & echo \$!; ";
                $pids = exec($command, $output);
            }
            $download_start = 1;
            mysqli_query($conn, "update videos_downloader set pid='" . $pids . "',download_start='" . $download_start . "' where id='" . $stream_id . "'");
            echo("update videos_downloader set pid='" . $pids . "',download_start='" . $download_start . "' where id='" . $stream_id . "'");
        }
    }
}
echo " ";
?>
