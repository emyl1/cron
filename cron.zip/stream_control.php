<?php
/*
 * @ PHP 7
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

set_time_limit(0);
include "/home/fox_codec/config.php";
include "/home/crons/cron_function.php";
$ser = mysqli_fetch_array(mysqli_query($conn, "select * from server where id=1"));
$server_ip = $ser["server_ip"];
$server_port = $ser["server_port"];
$bul = mysqli_query($conn, "SELECT * FROM channels where transcoding=0 && server_id=1 && stream_status=1");
if (mysqli_affected_rows($conn)) {
    while ($listeleme = mysqli_fetch_array($bul)) {
        $id = $listeleme["id"];
        $channel_path_1 = $listeleme["channel_path_1"];
        $channel_path_2 = $listeleme["channel_path_2"];
        $channel_path_3 = $listeleme["channel_path_3"];
        $pid = $listeleme["pid"];
        if (ps_running($pid) != NULL) {
            $filename = "/home/live/" . $id . "_.m3u8";
            if (file_exists($filename)) {
            } else {
                if ($pid == 0) {
                } else {
                    $cikti = "sudo kill -9 " . $pid;
                    shell_exec($cikti);
                }
                stream_stop($id);
            }
        } else {
            if (preg_match("/https:\\/\\/(www\\.)*youtube\\.com\\/.*/", $channel_path_1)) {
                preg_match("/[\\?\\&]v=([^\\?\\&]+)/", "" . $channel_path_1 . "", $youtube_link_1);
                $channes_path_1 = "http://" . $server_ip . ":" . $server_port . "/stream/youtube.php?watch?v=" . $youtube_link_1[1];
            } else {
                $channes_path_1 = $channel_path_1;
            }
            if (preg_match("/https:\\/\\/(www\\.)*youtube\\.com\\/.*/", $channel_path_2)) {
                preg_match("/[\\?\\&]v=([^\\?\\&]+)/", "" . $channel_path_2 . "", $youtube_link_1);
                $channels_path_2 = "http://" . $server_ip . ":" . $server_port . "/stream/youtube.php?watch?v=" . $youtube_link_1[1];
            } else {
                $channels_path_2 = $channel_path_2;
            }
            if (preg_match("/https:\\/\\/(www\\.)*youtube\\.com\\/.*/", $channel_path_3)) {
                preg_match("/[\\?\\&]v=([^\\?\\&]+)/", "" . $channel_path_3 . "", $youtube_link_1);
                $channels_path_3 = "http://" . $server_ip . ":" . $server_port . "/stream/youtube.php?watch?v=" . $youtube_link_1[1];
            } else {
                $channels_path_3 = $channel_path_3;
            }
            $checkstreamurl = shell_exec("/usr/bin/timeout 10s /home/ffmpeg/ffprobe -analyzeduration 10000000 -probesize 9000000 -i \"" . $channes_path_1 . "\" -v  quiet -print_format json -show_streams 2>&1");
            $streaminfo = (array) json_decode($checkstreamurl);
            if (0 < count($streaminfo)) {
                $working_channel = 1;
                mysqli_query($conn, "update channels set working_channel='" . $working_channel . "' where id='" . $id . "'");
            } else {
                $checkstreamurl = shell_exec("/usr/bin/timeout 10s /home/ffmpeg/ffprobe -analyzeduration 10000000 -probesize 9000000 -i \"" . $channels_path_2 . "\" -v  quiet -print_format json -show_streams 2>&1");
                $streaminfo = (array) json_decode($checkstreamurl);
                if (0 < count($streaminfo)) {
                    $working_channel = 2;
                    mysqli_query($conn, "update channels set working_channel='" . $working_channel . "' where id='" . $id . "'");
                } else {
                    $working_channel = 1;
                    mysqli_query($conn, "update channels set working_channel='" . $working_channel . "' where id='" . $id . "'");
                }
            }
        }
    }
}

?>
